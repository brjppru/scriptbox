#!/usr/bin/perl 

# copyright (c) Eugen J. Sobchenko, 2001

use DB_File;
use Fcntl;

sub usage {
    print "mkdb <dict database>\n";
    exit;
}

&usage unless $ARGV[0];

open(DICT, "<./EngRus.txt") || die "can't open ./EngRus.txt: $!";

undef my %dict;

while (<DICT>) {
    chomp;
    if (/(\S.+\S)\s+--\s+(\S.+)\s*$/) {
        $dict{$1}=$2;
    }
}

close DICT;
undef my %ddb;
my $db=tie %ddb, "DB_File", "$ARGV[0]", O_RDWR|O_CREAT, 0666;
my $fd=$db->fd();
open DATA, "+<&=$fd";
flock(DATA, LOCK_EX);
%ddb = %dict;
$db->sync;
undef $db;
untie %ddb;
close DATA;

