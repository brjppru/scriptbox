#! /usr/bin/perl

# _       __ _    by ejs@irc              
#| | ___ / _| |_ ___  __ _  __ _ 
#| |/ _ \ |_| __/ _ \/ _` |/ _` |
#| |  __/  _| ||  __/ (_| | (_| |
#|_|\___|_|  \__\___|\__, |\__, |
#                    |___/ |___/  
# Simple IRC robot written in perl 
# Copyright (C) 2000 Eugen J. Sobchenko 
# mailto: ejs@paco.net

eval {

    BEGIN {
        use strict;
        use locale;
        use IO::Handle;
		use Socket;
        use DB_File;
        use Fcntl;

        use vars qw(%CFG @ONCONN %reg_users %users %names %help %fwd %ignores %ops %voices %users, @modules, 
            @channels @childs @servers @users @e_publ_exp @e_actn_exp @publ_exp @priv_exp @serv_exp @ctcp_exp @join_sub @actn_exp
			@part_sub @quit_sub @kick_sub @mode_sub @topic_sub @nick_sub $nickorig
            $OS $VERSION $START_TIME $ntry $try $launched $ok $sn $lastping $lastprivnick $lastprivtime
			$lastprivmsg %lastpublnick %lastpubltime %lastpublmsg $lastctcpnick
			$lastctcptime $lastctcpmsg $lastmodech);

        # Required modules
        require "kernel/ostream.pl";
		require "kernel/configs.pl";
        require "kernel/logcore.pl";
        require "kernel/basicfunc.pl";
        require "kernel/ircore.pl";

		$OS=`uname -sr`; # I think its better than $^O
		chop($OS);
        $VERSION="1.68.0"; # Version of LeftEgg;
        $START_TIME=time; # start time
        $sn=0; # current server
        $ntry=$launched=$lastping=0;
        
        $SIG{'ALRM'} = \&isconnchk;        
    }

    $|++;

    &main();

    sub main {
        # perl monk was here (igorash@mail.od.ua)
        err('', '1', '', "its isecure to run leftegg as root") if $> == 0; 
        $try=0;
        my $gtry=0;
        my $try_old=$try;
        my $reply;

        if (defined($ARGV[0]) && !(-e $ARGV[0])) {
            status('', '', "$ARGV[0]: no such file");
            status('', '', "Usage: $0 [config]");
            exit();
        } elsif (defined($ARGV[0]) && -e $ARGV[0]) {
            parse_config($ARGV[0]);
            &parse_cfg_hash();
            parse_userfile($CFG{userfile});
			parse_helpfile($CFG{helpfile});
			parse_onconncfg($CFG{'connscp'}) if exists($CFG{'connscp'});
#            status('', '', "Okay, now \'$CFG{nick}\'.");
            $nickorig=$CFG{nick};
        } else {
            parse_config("egg.cfg");
            &parse_cfg_hash();
            parse_userfile($CFG{userfile});
			parse_helpfile($CFG{helpfile});
			parse_onconncfg($CFG{'connscp'}) if exists($CFG{'connscp'});
#            status('', '', "Okay, now \'$CFG{nick}\'.");
            $nickorig=$CFG{nick};
        }

        foreach (@modules) { require "modules/$_"; }

        ML:
        
        $try++;
        while ($try <= int scalar @servers) {
            connect_to_ircd() || goto ML; 
            ircd_raw_out("USER", "$CFG{username} foo bar :$CFG{ircname}");
            ircd_raw_out("NICK", "$CFG{nick}");
            my $verify=<IRC>;
            until (check_reply($verify) eq 'ok') {
                status('', '', "skipping."), goto ML if ($gtry > 10);
                $gtry++;
                $verify=<IRC>;
            }
            $ok = 'ok';
            unless ($launched == 1) {
                status('', '', "going to background.");
                fork() && exit(0);
            # writing pidfile
                open (PIDFILE, ">$CFG{pidfilesdir}/pid.$nickorig") ||
                    err('', '1', '', "cannot create $CFG{pidfilesdir}/pid.$CFG{nick}");
                print PIDFILE $$; # writing to pidfile 
                close PIDFILE;
            }
            if (defined($ONCONN[0])) {
                foreach (@ONCONN) {
                    sleep(0.5);
                    ircd_raw_out2($_);
                }
            }
            foreach my $channel (@channels) {
                if ($channel =~ /(\S+)\[(\S+)\]/) {
                    irc_join_chan($1, $2);
                } else {
                    irc_join_chan($channel);
                }
            }
            $launched = 1; 
            alarm (60);
            while ($reply=<IRC>) {
                $lastping = time();
                check_reply($reply);
            }
            close IRC; 
        }
        if ( $nok==1 ) {
            logndie("error.log", "Cannot connect to server.", 0600);
        } else {
            err('', '1', '', "Cannot connect to server.");
        }
    }

}; if ($@) {
logndie("error.log", "$@", 0600);
} # halleluiah


