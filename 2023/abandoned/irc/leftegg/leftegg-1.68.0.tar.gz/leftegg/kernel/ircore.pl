# Copyright (c) Eugen J. Sobchenko // ejs@paco.net

BEGIN {
#	$SIG{'CHLD'}='IGNORE'; # disable zombies
	$SIG{'HUP'} = sub {
		logit('error.log', "Got HUP sig!", 0600);
	};
    $SIG{'TERM'} = sub {
        quit_irc("killed");
    };
	use strict 'vars';
}

# connects to irc-server
#sub connect_to_ircd {
#    my ($server, $port) = split ":", $servers[$sn];
#	select(STDOUT);
#	STDOUT->autoflush(1);
#    status('', '', "Connecting to $server:$port...");
#	my $them=$server;
#	my $proto = (getprotobyname('tcp'))[2];
#	$port = (getservbyname($port,'tcp'))[2]
#								unless $port =~ /^\d+$/;
#	my $hostname=undef;
#	if ($CFG{'hostname'}) { $hostname=$CFG{'hostname'}; } else {
#		chop($hostname = `hostname`); }
#	my $a_addr = (gethostbyname($hostname))[4];
#	my $b_addr = (gethostbyname($them))[4];
#	socket(IRC,AF_INET,SOCK_STREAM,$proto) || $sn++ & return 0;
#	my $sockaddr = 'S n a4 x8';
#	my $a = pack($sockaddr,AF_INET,0,$a_addr);
#	my $b = pack($sockaddr,AF_INET,$port,$b_addr);
#	bind(IRC,$a) || $sn++ & return 0;
#	connect(IRC,$b) || $sn++ & return 0;

#	IRC->autoflush(1);
#   	$sn++;
#   	$sn=0 if ($sn >= scalar @servers);
#   	return 1;
#}

sub connect_to_ircd {
    my ($host, $port) = split ":", $servers[$sn];
    select(STDOUT);
    STDOUT->autoflush(1);
    status('', '', "connecting to $host:$port...") unless ($launched == 1);
    my ($adr, $otherend)=resolve($host);
    unless ($adr) {
    status('', '', "hostname '$host' not found") unless ($launched == 1);
    $sn++ & return 0;
    }
    $otherend=pack("S n a4 x8", &AF_INET, $port, $adr);
    unless (socket(IRC, &PF_INET, &SOCK_STREAM, 0)) {
    status('', '', "out of file descriptors") unless ($launched == 1);
    return 0;
    }
    undef my $bindaddr;
    if ($CFG{'vhost'}) {
        $bindaddr = resolve($CFG{'vhost'});
        unless(bind(IRC, pack("S n a4 x8", &AF_INET, 0, $bindaddr))) {
            status('', '', "can't bind to address") unless ($launched == 1);
            $sn++ & return 0;
        }
    }
    $sn++ & return 0 unless connect(IRC, $otherend);
    $bindaddr=(unpack("S n a4", getsockname(IRC)))[2] if !$bindaddr;
    select(IRC); $|=1; select(STDOUT);
    $sn++;
    $sn=0 if ($sn >= scalar @servers);   
    return 1;
}

sub resolve {
  if ($_[0] =~ /^\d+$/) {
    return pack("N", $_[0]+0);
  } elsif ($_[0] =~ /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/) {
    return pack("c4", $1, $2, $3, $4);
  } else {
    return (gethostbyname($_[0]))[4];
  } 
}   

sub isconnchk {
    if ((time() - $lastping) > 600) {  
        foreach (@childs) {
            kill 9, $_;
        }
        logit("events.log", "Disconnected from server [dying]", 0600);
        exit;
    } else {
        if ($CFG{'keepnick'} == 1) {
            unless (lc $CFG{nick} eq lc $nickorig) {
                ch_nick($nickorig);
            }
        }
        alarm(60);
    }
}

# prints arguments intto socket handle
sub ircd_raw_out {
    my ($what, $args) = @_;
    print IRC "$what $args" . "\n";
}

sub ircd_raw_out2 {
	my $what = shift;
	print IRC $what . "\n";
}

# channel join
sub irc_join_chan {
    my $channel = shift;
    my $key = shift;
    if ($key) {
        ircd_raw_out("JOIN", "$channel $key");
    } else {
        ircd_raw_out("JOIN", "$channel");
    }
}

# channel part
sub irc_leave_chan {
    my $channel = shift;
    my $reason = shift;
    $reason="bye" unless defined($reason);
    ircd_raw_out("PART", "$channel $reason");
    for (my $i=0; $i<(scalar(@channels)); $i++) {
	    if (lc $channels[$i] eq lc $channel) {
			splice(@channels, $i, 1);
    	}
    }
    if (exists($names{lc($channel)})) {
	    delete($names{lc($channel)});
    }
}

# quit irc
sub quit_irc {
    ircd_raw_out("QUIT",":$_[0]");
    foreach (@childs) {
        kill 9, $_;
    }
    exit;
}

# change nick
sub ch_nick {
    ircd_raw_out("NICK",$_[0]);
    $CFG{nick}=$_[0];
}

# mode
sub irc_mode {
    my ($channel, $modes) = @_;
   	ircd_raw_out("MODE", "$channel $modes");
}

#kick
sub irc_kick {
	my ($channel, $nick, $reason) = @_;
	ircd_raw_out2("KICK $channel $nick :$reason");
}

# message
sub irc_msg {
    my ($to, $text) = @_;
    ircd_raw_out("PRIVMSG", "$to :$text");
    if ($to =~ /([\#\&]\S+)$/) {
        logit($1, "<$CFG{nick}> $text");
    }
}

# change topic
sub ch_topic {
	my ($to, $text) =@_;
	ircd_raw_out("TOPIC", "$to :$text");
} 

# notice
sub irc_notice {
    my ($to, $text) = @_;
    ircd_raw_out("NOTICE", "$to :$text");
}

# action
sub irc_action {
    my ($to, $text) = @_;
    ircd_raw_out($to, "ACTION", $text);
    if ($to =~ /([\#\&]\S+)$/) {
        logit($1, "* $CFG{nick} $text");
    }
}

# ctcp reply
sub irc_ctcp {
    my ($to, $type, $text) = @_;
    ircd_raw_out("NOTICE", "$to :\x01$type $text\x01");
}

# checks and parses server messages
sub check_reply {
    chomp(my $reply=shift);
    my ($A, $SrvMsg, @Args) = split ":", $reply;
	foreach my $d (@Args) { chomp($d); }
    my $text = join ":", @Args;
    $text =~ s/[\n\r]//g;
    my ($r_nick, $r_host);
    my @bit;

    if ("PING" eq substr $A, 0, 4) {
        # pings are important!
        ircd_raw_out("PONG", "$SrvMsg");
    } else {
        # its not a ping, parsing
        @bit = split(/\s+/, $SrvMsg);
        if ($SrvMsg =~ /^(\S+)!(\S+\@\S+).*$/) {
			$r_nick = $1;
			$r_host = $2;
		} elsif ($SrvMsg =~ /^(\S+)/) {
			($r_nick, $r_host) = $1;
		}
    }

    if ($bit[1] =~ /^(001|002|003)$/) {
        # success!
        return 'ok';
    } elsif ($bit[1] eq "433") {
        # nickname already in use
        unless ($ok eq 'ok') {
            unless ($ntry == 3) {
                $CFG{'nick'}=$CFG{'nick'}.'_';
                logit('events.log', "Nickname \'$bit[3]\' already in use... Trying \'$CFG{nick}\'.", 0600);
                ch_nick($CFG{'nick'});
            } else {
                logndie("error.log", "Nickname \'$bit[3]\' already in use [dying]", 0600);
            }
            $ntry++;
        } else { return; } 
        
    } elsif ($bit[1] eq "332") {
        # topic
    } elsif ($bit[1] eq "MODE" && lc $bit[2] eq lc $CFG{nick}) {
        # user mode
        logit('events.log', "*** mode $CFG{nick} $text", 0600);
    } elsif ($bit[1] eq "JOIN") {
        # channel join
		logit($text, "*** $r_nick [$r_host] has joined $text");
        unless (lc $r_nick eq lc $CFG{nick}) {
			join_chk($r_nick, $r_host, $text);
        } else {
            foreach my $e (@channels) {
                if (lc($e) eq lc($text)) {
                    goto HELL;
                }
            }
            push @channels, lc($text);
        }
        HELL: # Perl monk was here :-)
    } elsif ($bit[1] eq "353") {
        # names on channel
		foreach my $e (@channels) {
			if ($e eq lc($bit[4])) {
				delete($ops{lc($bit[4])}) if exists($ops{lc($bit[4])});
				delete($voices{lc($bit[4])}) if exists($voices{lc($bit[4])});
				delete($users{lc($bit[4])}) if exists($users{lc($bit[4])});
				my @names; 
				push @names, split(/\s+/, lc($text));
				foreach my $x (@names) {
					if (substr($x, 0, 1) eq '@') {
						# user is opped
						$x=~ s/[\@]//g;
						push @{$ops{lc($bit[4])}}, $x;
					} elsif (substr($x, 0, 1) eq '+') {
						# user is voiced
						$x=~ s/[\+]//g;
						push @{$voices{lc($bit[4])}}, $x;
					} else {
						push @{$users{lc($bit[4])}}, $x;
					}
				}	
        		$text =~ s/[\@\+]//g;
				delete($names{lc($bit[4])}) if exists($names{lc($bit[4])});
        		push @{$names{lc($bit[4])}}, split(/\s+/, lc($text));
			}
		}
    } elsif ($bit[1] eq "PART") {
        # somebody left channel
        logit($bit[2], "*** $r_nick [$r_host] has left channel $bit[2] ($text)");
        unless (lc $r_nick eq lc $CFG{nick}) {
			part_chk($r_nick, $r_host, $bit[2], $text);
        } else {
            if (exists($names{lc($bit[2])})) {
                delete($names{lc($bit[2])});
            }
	        for (my $i=0; $i<(scalar(@channels)); $i++) {
    	        if (lc $channels[$i] eq lc $bit[2]) {
        	        splice(@channels, $i, 1);
            	}
        	}
		}
    } elsif ($bit[1] eq "MODE" && $bit[4] ne '') {
        # mode
		my (@qax, $done);
		$done=0;
		push @qax, $bit[4];
		push @qax, $bit[5] if ($bit[5] ne '');
		push @qax, $bit[6] if ($bit[6] ne '');
        logit($bit[2], "*** mode $bit[3] ".join(' ', @qax)." on $bit[2] by $r_nick");
		mode_chk($r_nick, $r_host, $bit[2], $bit[3], @qax);
    } elsif ($bit[1] eq "MODE" && $bit[4] eq '') {
		# mode
        logit($bit[2], "*** mode $bit[3] on $bit[2] by $r_nick");
		mode_chk($r_nick, $r_host, $bit[2], $bit[3]);
    } elsif ($bit[1] eq "TOPIC") {
        # topic change
        logit($bit[2], "*** $r_nick has changed topic on $bit[2] to: $text");
		topic_chk($bit[2], $text, $r_nick, $r_host);
    } elsif ($bit[1] eq "NICK") {
        # nick change
        unless (lc $r_nick eq lc $CFG{nick}) {
            my @where = get_where($r_nick);
            foreach my $e (@where) {
                logit($e, "*** $r_nick has changed nick to $text");
            }
			nick_chk($r_nick, $r_host, $text);
        } else {
            $CFG{nick} = $text;
			my @where=get_where($r_nick);
            foreach my $e (@where) {
                logit($e, "*** $r_nick has changed nick to $text");
            }
        }
    } elsif ($bit[1] eq "QUIT") {
        # quit
		my @where=get_where($r_nick);
		foreach my $e (@where) {
			logit($e, "*** $r_nick [$r_host] has quit irc ($text)");
		} 
		quit_chk($r_nick, $r_host, $text);
    } elsif ($bit[1] eq "KICK") {
        # kick
        if (lc($bit[3]) eq lc($CFG{nick})) {
            # we're kicked?!
            logit($bit[2], "*** we were kicked from $bit[2] by $r_nick ($text)");
            logit('events.log', "We were kicked from $bit[2] by $r_nick [$r_host] ($text)", 0600);
            for (my $i=0; $i<(scalar(@channels)); $i++) {
            	if (lc $channels[$i] eq lc $bit[2]) {
                	splice(@channels, $i, 1);
            	}
        	}
            if (exists($names{lc($bit[2])})) {
                delete($names{lc($bit[2])});
            }
            ircd_raw_out("JOIN", "$bit[2]") unless (exists($CFG{noautorejoin}) && $CFG{noautorejoin}==1);
        } else {
            logit($bit[2], "*** $bit[3] was kicked from $bit[2] by $r_nick ($text)");
			kick_chk($bit[3], $r_nick, $r_host, $bit[2], $text);
        }
    } elsif ($bit[1] eq "PRIVMSG" && ("\x01" eq substr $text, 0, 1)) {
        $text =~ s/[]//g;
        if ("ACTION " eq substr $text, 0, 7) {
            # action
            $text =~ s/ACTION\s+//;
            if (lc $bit[2] eq lc $CFG{nick}) {
                # private
                logit('events.log', "msg *action* from $r_nick [$r_host]: $text", 0600);
            } else {
                # public
				actionhook($bit[2], $r_nick, $r_host, $text);
            }
        } else {
            # ctcp request
			ctcphook($r_nick, $r_host, $text);
        }
    } elsif ($bit[1] eq "PRIVMSG" && lc $bit[2] eq lc $CFG{nick}) {
        # private msg
		privhook($r_nick, $r_host, $text);
    } elsif ($bit[1] eq "PRIVMSG" && $bit[2] =~ /[\#\&].*?/) {
        # channel msg
        my $channel = lc($bit[2]);
        publhook($channel, $r_nick, $r_host, $text);
    } elsif ($bit[1] eq "NOTICE" && lc $bit[2] eq lc $CFG{nick}) {
        # private notice
        logit('events.log', "*** notice from $r_nick [$r_host]: $text", 0600);
  } elsif ($bit[1] eq "NOTICE" && $bit[2] =~ /[\#\&].*?/) {
        # public notice
        logit($bit[2], "*notice* from $r_nick: $text");
  }

    # Uncomment everything below if you want LeftEgg to write
    # unknown server messages to unknown.log
    
#      else {
#     my $bitcount=0;
#     my $argcount=0;
     check_serv_reply($reply);
#     logit('unknown.log', $reply);
#     logit('unknown.log', "text: $text");
#     foreach(@bit) {
#          logit('unknown.log', "bit$bitcount: $_");
#         $bitcount++;
#     }
#   } 
}

# checking server messages
sub check_serv_reply {
    my $SrvMsg=shift;
    foreach my $e (@serv_exp) {
        my ($subn, $exp) = split (/::/, $e);
        if ($SrvMsg =~ /$exp/i) {
            &{$subn}($SrvMsg);
        }
    }
}

# checking public messages
sub check_publ {
    my ($channel, $r_nick, $r_host, $text) = @_;
    $channel=lc($channel);
    foreach my $e (@publ_exp) {
        my ($subn, $exp) = split (/::/, $e);
        if ($text =~ /$exp/i) {
            &{$subn}($text, $channel, $r_nick, $r_host);
        }
    }
}

sub check_epubl {
    my ($channel, $r_nick, $r_host, $text) = @_;
    $channel=lc($channel);
    foreach my $e (@e_publ_exp) {
        my ($subn, $exp) = split (/::/, $e);
        if ($text =~ /$exp/i) {
            &{$subn}($text, $channel, $r_nick, $r_host);
        }
    }
}

sub check_actn {
    my ($channel, $r_nick, $r_host, $text) = @_;
    $channel=lc($channel);
    foreach my $e (@actn_exp) {
        my ($subn, $exp) = split (/::/, $e);
        if ($text =~ /$exp/i) {
            &{$subn}($text, $channel, $r_nick, $r_host);
        }
    }
}

sub check_eactn {
    my ($channel, $r_nick, $r_host, $text) = @_;
    $channel=lc($channel);
    foreach my $e (@e_actn_exp) {
        my ($subn, $exp) = split (/::/, $e);
        if ($text =~ /$exp/i) {
            &{$subn}($text, $channel, $r_nick, $r_host);
        }
    }
}


# checking private messages
sub check_priv {
    my ($r_nick, $r_host, $text) = @_;
    foreach my $e (@priv_exp) {
        my ($subn, $exp) = split (/::/, $e);
        if ($text =~ /$exp/i) {
            &{$subn}($text, $r_nick, $r_host);
        }
    }
}

# checking ctcp messages
sub check_ctcp {
    my ($r_nick, $ctcp_cmd) = @_;
    foreach my $e (@ctcp_exp) {
        my ($subn, $exp) = split (/::/, $e);
        if ($ctcp_cmd =~ /$exp/i) {
            &{$subn}($r_nick, $ctcp_cmd);
        }
    }
}

# returns array with channels where is specified nick sits
sub get_where {
    my $nick = shift;
    my @where;
	foreach my $e (@channels) {
		ircd_raw_out2("NAMES $e");
	}
    foreach my $channel (@channels) {
        foreach my $name (@{$names{lc($channel)}}) {
            if (lc $name eq lc $nick) {
                push @where, $channel;
            }
        }
    }
    return @where;
}

sub is_opped {
	my ($nick, $where) =@_;
	ircd_raw_out2("NAMES $where");
	foreach my $name (@{$ops{lc($where)}}) {
		if (lc $name eq lc $nick) {
			return "true";
		}
	}
	return "false";
}

sub is_voiced {
	my ($nick, $where) =@_;
    ircd_raw_out2("NAMES $where");
	foreach my $name (@{$voices{lc($where)}}) {
		if (lc $name eq lc $nick) {
			return "true";
		}
	}
	return "false";
}

# onjoin check
sub join_chk {
    my ($r_nick, $r_host, $channel) = @_;
    #my $r_mask="$r_nick!$r_host";
    my $res=chkflags($r_nick, $r_host, "O");
    if ($res eq "true") {
        irc_mode($channel, "+o $r_nick");
    } else {
        $res=chkflags($r_nick, $r_host, "V");
        if ($res eq"true") {
            irc_mode($channel, "+v $r_nick");
        }
    }
    irc_msg($channel, "[$r_nick] $reg_users{lc($r_nick)}{greet}") if
        exists($reg_users{lc($r_nick)}{greet});
    foreach my $e (@join_sub) {
        &{$e}($r_nick, $r_host, $channel);
    }
}

sub part_chk {
	my ($r_nick, $r_host, $channel, $reason) = @_;
	$channel = lc($channel);
	foreach my $e (@part_sub) {
        &{$e}($r_nick, $r_host, $channel, $reason);
    }
}

sub quit_chk {
	my ($r_nick, $r_host, $reason) = @_;
	foreach my $e (@quit_sub) {
		&{$e}($r_nick, $r_host, $reason);
	}
}

sub kick_chk {
	my ($who, $r_nick, $r_host, $channel, $reason) = @_;
	$channel=lc($channel);
	foreach my $e (@kick_sub) {
		&{$e}($who, $r_nick, $r_host, $channel, $reason);
	}
}

sub mode_chk {
	my ($r_nick, $r_host, $channel, $mode, @qax) =@_;
	$channel = lc($channel);
	foreach my $e (@mode_sub) {
		&{$e}($r_nick, $r_host, $channel, $mode, @qax);
	}
}

sub topic_chk {
	my ($channel, $topic, $r_nick, $r_host) =@_;
	$channel=lc($channel);
	foreach my $e (@topic_sub) {
		&{$e}($channel, $topic, $r_nick, $r_host);
	}
}

sub nick_chk {
	my ($r_nick, $r_host, $newnick) =@_;
	foreach my $e (@nick_sub) {
		&{$e}($r_nick, $r_host, $newnick);
	}
}

sub privhook {
	my ($r_nick, $r_host, $text) =@_;
	if (exists($ignores{lc($r_nick)})) {
		return if ((time()-$ignores{lc($r_nick)}) < 30);
		delete($ignores{lc($r_nick)});
	}
	if ($lastprivnick eq lc $r_nick) {
		my $delay=time() - $lastprivtime;
		if ($delay <= 1) {
			if (chkflags($r_nick, $r_host, "n") ne "true") {
				logit('events.log', "msg flood from $r_nick [$r_host]", 0600);
				$ignores{lc($r_nick)}=time;
				irc_notice($r_nick, "flood detected, ignoring for 30 seconds");
				return;
			}
		}
		return if (($text eq $lastprivmsg) && ($delay < 10));
	} 
	$lastprivtime = time();
	$lastprivmsg=$text;
	$lastprivnick=lc($r_nick);
	logit('events.log', "msg from $r_nick [$r_host]: $text", 0600);
	check_priv($r_nick, $r_host, $text);
}

sub publhook {
	my ($channel, $r_nick, $r_host, $text) =@_;
	logit($channel, "<$r_nick> $text");
	check_epubl($channel, $r_nick, $r_host, $text);
    if ($lastpublnick{lc($channel)} eq lc($r_nick)) {
        my $delay=time() - $lastpubltime{lc($channel)};
        if ($delay < 1) {
            if (chkflags($r_nick, $r_host, "n|o|O") ne "true") {
                return;
            }
        }
        return if (($text eq $lastpublmsg{lc($channel)}) && ($delay < 10));
    }
    $lastpubltime{lc($channel)} = time();
    $lastpublmsg{lc($channel)}=$text;
    $lastpublnick{lc($channel)}=lc($r_nick);
	check_publ($channel, $r_nick, $r_host, $text);
}

sub actionhook {
    my ($channel, $r_nick, $r_host, $text) =@_;
    logit($channel, "* $r_nick $text");
	check_eactn($channel, $r_nick, $r_host, $text);
    if ($lastpublnick{lc($channel)} eq lc($r_nick)) {
        my $delay=time() - $lastpubltime{lc($channel)};
        if ($delay < 1) {
            if (chkflags($r_nick, $r_host, "n|o|O") ne "true") {
                return;
            }
        }
        return if (($text eq $lastpublmsg{lc($channel)}) && ($delay < 10));
    }
    $lastpubltime{lc($channel)} = time();
    $lastpublmsg{lc($channel)}=$text;
    $lastpublnick{lc($channel)}=lc($r_nick);
    check_actn($channel, $r_nick, $r_host, $text);
}

sub ctcphook {
	my ($r_nick, $r_host, $text) =@_;
	if ($lastctcpnick eq lc($r_nick)) {
		my $delay=time() - $lastctcptime;
		if ($delay < 3) {
			if (chkflags($r_nick, $r_host, "n|o|O") ne "true") {
				logit('events.log', "ctcp flood from $r_nick [$r_host]", 0600);
				return;
			}
		}
		return if (($text eq $lastctcpmsg) && ($delay < 10));
	}
    $lastctcptime = time();
    $lastctcpmsg=$text;
    $lastctcpnick=lc($r_nick);
	if ('PING' eq substr $text, 0, 4) {
		logit('events.log', "*** ctcp PING request from $r_nick [$r_host]", 0600); 
	} else {
		logit('events.log', "*** ctcp $text request from $r_nick [$r_host]", 0600);
	}
    check_ctcp($r_nick, $text);
}

1;
