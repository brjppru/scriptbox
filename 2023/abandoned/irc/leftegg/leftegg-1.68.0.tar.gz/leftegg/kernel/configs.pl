# Copyright (c) Eugen J. Sobchenko // ejs@paco.net

# parsing main configuration file - egg.cfg
sub parse_config {
    my $file = shift;
    status('', '1', "parsing $file...");
    open(CONFIG, "<$file") || err('', '1', '', "can't open config file for reading");
    while (<CONFIG>) {
        chomp;
        next if /^\s*\#/;
        next unless /^\s*\S/;
        s/^(.+)\r$/$1/gs;
        my ($key, $value) = split(/\s+/, $_, 2);
        chop($value) while (' ' eq substr($value, -1));
        if ($key eq 'load') {
            push @modules, $value;
        } else {
            $value =~ s/(\$(\w+))/$CFG{$2}/g;
            $CFG{$key} = $value;
        }
    }
    close(CONFIG);
    return %CFG;
}

sub parse_onconncfg {
	my $file =shift;
	status('', '1', "parsing $file...");
	if (-e $file) {
		open(CONNFILE, "<$file") || err('', '1', '', "can't open config file for reading");
		while (<CONNFILE>) {
			chomp;
			next if /^\s*\#/;
			next unless /^\s*\S/;
            s/^(.+)\r$/$1/gs;
			push @ONCONN, $_;
		}
		close(CONNFILE);
	} else {
		err('', '1', '', "conn script not exists");
	}
	return @ONCONN;
}

# helpfile
sub parse_helpfile {
	my $file = shift;
	foreach my $key (keys %help) {
		delete($help{$key});
	}
	logndie('error.log', "userfile not exists", '0600') unless
					(-e $file);
	open (HELPFILE, "<$file") || err('', '1', '', "can't open helpfile for reading");
	while (<HELPFILE>) {
		chomp;
		next if /^\s*\#/;
		next unless /^\s*\S/;
        s/^(.+)\r$/$1/gs;
		if (/^\s*record\s+(\S+)\s+/) {
			my $current = lc($1);
			if (/\s*\{\s*/) {
				while (<HELPFILE>) {
					chomp;
					next if /^\s*\#/;
					next unless /^\s*\S/;
					if (/\s*(\S.+\S)\s*$/) {
						push @{$help{$current}{cont}}, $1;
					} elsif (/^\s*\}\s*$/) {
						last;
					}
				}
			} else {
				logndie('error.log', "in $file. Record $current without right brace", '0600');
			}
		}
	}
	close HELPFILE;
	return 1;
}

# parsing userfile - $CFG{userfile}
sub parse_userfile {
    my $file = shift;
    undef @users;
    foreach my $key (keys %reg_users) {
        delete($reg_users{$key});
    }
    if (-e $file) {
        open(USERFILE, "<$file") || err('', '1', '', "can't open userfile for reading");
        while (<USERFILE>) {
            chomp;
            next if /^\s*\#/;
			next unless /^\s*\S/;
            s/^(.+)\r$/$1/gs;
            if (/^\s*user\s+(.+?)\s+/) {
                push @users, lc($1);
                my $current = lc($1);
                err('', '1', '', "Hey! Users with same nicks are not allowed in userfile!")
                    if exists $reg_users{$current};
                if (/\s*\{\s*/) {
                    while (<USERFILE>) {
						chomp;
                        next if /^\s*\#/;
                        next unless /^\s*\S/;
                        if (/^\s*(\w+)\s+(.+)\s*;\s*$/) {
                            my $option = $1; my $value = $2;
                            $value =~ s/\"//g;
                            if ($option =~ /^masks$/i) {
                                push @{$reg_users{$current}{masks}}, split(/\s+/, $value);
                            } elsif ($option =~ /^flags$/i) {
                                $value =~ s/\+//;
                                $reg_users{$current}{flags} = $value;
                            } elsif ($option =~ /^channels$/i) {
                                push @{$reg_users{$current}{channels}}, split(/\s+/, $value);
                            } else {
                                $option =~ tr/A-Z/a-z/;
                                $reg_users{$current}{$option} = $value;
                            }
                        } elsif (/^\s*\}\s*$/) {
                            last;
                        }
                    }
                } else {
                    logndie('error.log', "in $file. User $current without right brace", '0600');
                }
            }
        }
    } else {
        logndie('error.log', "userfile not exists", '0600');
    }
#    foreach my $user (@users) {
#        foreach my $mask (@{$reg_users{$user}{masks}}) {
#            $mask =~ s/\*/.\*?/g;
#            $mask =~ s/([\@\(\)\[\]])/\\$1/g;
#        }
#    }
    #    foreach my $user (@users) {
    #	if (${$reg_users{$user}{channels}}[0] eq "*") {
    #		${$reg_users{$user}{channels}}[0] = ".*";
    #	}
    #   }
    return 1;
}

sub write_cfg {
    my $file = shift;
    open (FILE, ">$file") || logndie('error.log', "can't open $file: $!");
    foreach my $u (@users) {
        print FILE "user $u \{\n";
        foreach my $p (sort keys %{$reg_users{$u}}) {
             print FILE "\t$p ";
             if (ref($reg_users{$u}{$p}) eq 'ARRAY') {
                print FILE join(' ', @{$reg_users{$u}{$p}});
             } else {
                print FILE $reg_users{$u}{$p};
             }
             print FILE ";\n"
        }
        print FILE "\}\n\n";
    }
    close FILE;
}

# parsing cfg hash
sub parse_cfg_hash {
    # checking if all important variables defined
    err('', '1', '', "nick value is nod defined") unless ($CFG{nick});
    err('', '1', '', "datadir value is not defined") unless ($CFG{datadir});
    err('', '1', '', "logdir value is not defined") unless ($CFG{logdir});
    err('', '1', '', "servers value is not defined") unless ($CFG{servers});
	err('', '1', '', "helpfile value is not defined") unless ($CFG{helpfile});
    mkdir $CFG{datadir}, 0775 unless (-d $CFG{datadir});
    mkdir $CFG{logdir}, 0775 unless (-d $CFG{logdir});
    &check_o($CFG{datadir});
    &check_o($CFG{logdir});
    &check_r($CFG{datadir});
    &check_w($CFG{datadir});
    &check_w($CFG{logdir});
    err('', '1', '', "channels value is not defined") unless ($CFG{channels});
    err('', '1', '', "owner value is not defined") unless ($CFG{owner});
#    err('', '1', '', "datafile value is not defined") unless ($CFG{datafile});
#    err('', '1', '', "seendb value is not defined") unless ($CFG{seendb});
    err('', '1', '', "userfile value is not defined") unless ($CFG{userfile});
    # setting alternate variables
    $CFG{pidfilesdir}="." unless (exists($CFG{pidfilesdir}));
    chop($CFG{pidfilesdir}) if $CFG{pidfilesdir} =~ /\/$/;
    chop($CFG{datadir}) if $CFG{datadir} =~ /\/$/;
    chop($CFG{logdir}) if $CFG{logdir} =~ /\/$/;
    $CFG{quitmsg}="LeftEgg-$VERSION" unless (exists($CFG{quitmsg}));
    $CFG{ircname}=$CFG{nick} unless (exists($CFG{ircname}));
    $CFG{username}=$CFG{nick} unless (exists($CFG{ircname}));
    foreach my $k (sort keys %CFG) { $CFG{$k} =~ s|\s*$||; }
    # creating arrays for servers and channels
    push @channels, split(/\s+/, $CFG{channels});
    push @servers, split(/\s+/, $CFG{servers});
	if (exists($CFG{'logging'})) {
		push @{$CFG{'logging'}}, split(/\s+/, $CFG{'logging'});
	}
}

# checks own 
sub check_o {
    my ($obj) = shift;
    if (-o $obj) { return 1; } else {
        err('', '1', '', "\'$obj\' owned by someone else");
    }
}

# checks +w 
sub check_w {
    my $obj = shift;
    if (-w $obj) { return 1; } else {
        err('', '1', '', "\'$obj\' without write permission");
    }
}

# checks +r 
sub check_r {
    my $obj = shift;
    if (-r $obj) { return 1; } else {
        err('', '1', '', "\'$obj\' without read permission");
    }
}

# checks +x 
sub check_x {
    my $obj = shift;
        if (-x $obj) { return 1; } else {
            err('', '1', '', "\'$obj\' without execute permission");
        }
}

1;
