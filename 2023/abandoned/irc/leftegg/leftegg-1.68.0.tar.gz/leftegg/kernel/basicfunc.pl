# Copyright (c) Eugen J. Sobchenko // ejs@paco.net

# returns difference between specified time (@_[0]) and current
sub time_diff {
    my $time = shift;
    my $bree = time;
    my $diff = $bree - $time;
    my $seconds = $diff % 60;
    $diff = ($diff - $seconds) / 60;
    my $minutes = $diff % 60;
    $diff = ($diff - $minutes) / 60;
    my $hours = $diff % 24;
    $diff = ($diff - $hours) / 24;
    my $days = $diff % 7;
    my $weeks = ($diff - $days) / 7;
	if ($weeks==0 && $days==0 && $hours==0 && $minutes==0) {
		$diff="$seconds seconds";
	} elsif ($weeks==0 && $days==0 && $hours==0 && $minutes!=0) {
		$diff="$minutes minutes and $seconds seconds";
	} elsif ($weeks==0 && $days==0 && $hours!=0) {
		$diff="$hours hours, $minutes minutes and $seconds seconds";
	} elsif ($weeks==0 && $days!=0) {
		$diff="$days days, $hours hours, $minutes minutes and $seconds seconds";
	} else {
		$diff="$weeks weeks, $days days, $hours hours, $minutes minutes and $seconds seconds";
	}
    return $diff;
}


# returns current date
sub now_date {
my (undef,undef,undef,$mday,$mon,$year) = localtime(time);
$year += 1900; #yay, y2k!
$mon += 1;
my $date=sprintf('%d.%02d.%02d', $year, $mon, $mday);
return $date;
}

# returns current time
sub now_time {
my ($sec,$min,$hour) = localtime(time);
my $time = sprintf('%02d:%02d:%02d', $hour, $min, $sec);
return $time;
}
    
# checking flags of specified user
sub chkflags {
    my ($r_nick, $r_host, $flags) = @_;
	$r_host=chop_mask($r_host);
    my $r_mask="$r_nick!$r_host";
    foreach my $user (@users) {
        foreach my $mask (@{$reg_users{$user}{masks}}) {
            my $d=$mask;
            $d =~ s/\*/.\*?/g;
            $d =~ s/([\@\(\)\[\]])/\\$1/g;
            if ($r_mask =~ /$d/) {
                if ($reg_users{$user}{flags} =~ /[$flags]/) {
                    return "true";
                }
            }
        }
    }
    return "fuck off";
}

# cutting '^' and '~' from ident
sub chop_mask {
    my $mask = shift;
    $mask=~/(.+)\@(.+)/;
    my ($ident,$host) = ($1,$2);
    if ($ident=~/^\^/) {
        $ident=~s/^\^//;
    } elsif ($ident=~/^\~/) {
        $ident=~s/^\~//;
    }
    return $mask="$ident\@$host";
}

1;
