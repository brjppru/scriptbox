# Copyright (c) Eugen J. Sobchenko // ejs@paco.net

sub logit {
    my ($to, $what, $mode) = @_;
	return if $to =~ /^\s*$/;
	$mode=0644 unless defined($mode);
    $to=lc($to);
	return if ($to ne "error.log" && exists($CFG{'nologging'}) && $CFG{'nologging'}==1);
	if ($to=~/[\#\&].*?/ && exists($CFG{logging})) {
		foreach (@{$CFG{logging}}) {
			if (lc($_) eq $to) {
				goto NL;
			}
		}
		return;
	}
NL:
    my $date = now_date();
    my $time = now_time();
    $to="$to--$date";
    open (LOGFILE, ">>$CFG{logdir}/$to") || err('', '1', '', "can't open \"$to\" ($!)");
	chmod $mode, "$CFG{logdir}/$to";
    print LOGFILE ("[" . $time . "] " . $what . "\n");
    close (LOGFILE);
}

sub logndie {
    my ($to, $what, $mode) = @_;
	return if $to =~ /^\s*$/;
	$mode=0644 unless defined($mode);
    $to=lc($to);
    my $date = now_date();
    my $time = now_time();
    $to="$to--$date";
    open (LOGFILE, ">>$CFG{logdir}/$to") || err('', '1', '', "can't open \"$to\" ($!)");
	chmod $mode, "$CFG{logdir}/$to";
    print LOGFILE ("[" . $time . "] " . $what . "\n");
    close (LOGFILE);
    err('', '1', '', "$what");
}

1;
