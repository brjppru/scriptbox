# Copyright (c) Eugen J. Sobchenko // ejs@paco.net

use strict;

sub status {
    err('', '1', '', "incorrect \'status\' usage") if
        ((int scalar @_) != 3);
    my ($to, $eol, $text) = @_;
    $to=*STDOUT unless ($to);
    $eol=1 unless ($eol);
    if ($eol == 1) { print $to "$text"."\n"; }
    else { print $to "$text"; }
}

sub err {
    err('', '1', '', "incorrect \'err\' usage") if
        ((int scalar @_) != 4);
    my ($to, $level, $eol, $text) = @_;
    $to=*STDERR unless ($to);
    $level=0 unless ($level);
    $eol=1 unless ($eol);
    if ($eol == 1) { print $to "Error: $text"."\n"; }
    else { print $to "Error: $text"; }
    exit(0) if ($level == 1);
}

1;
