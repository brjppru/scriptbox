#!/usr/bin/perl

# simple thing to create passfiles for egglog
# copyright (c) 2001 Eugen J. Sobchenko // ejs@paco.net
# thanks to Mike B. Vladimirsky // mvlad@ixcelerator.com

use strict;

&usage unless ($ARGV[0]);

sub usage {
	print "usage: mkpass.pl <passfile>\n";
	exit;
}

&mk_password();
sub mk_password {                                                         
		 print "Login: ";
		 chomp(my $login = <STDIN>);
         srand;                                                            
         system("stty -echo");                                             
         printf("Password: ");                                         
         chomp(my $passwd = <STDIN>);                                      
         my @chars = ('A'..'Z', 'a'..'z', '0'..'9', qw('.' '/'));          
         my $salt = join('', @chars [map { rand @chars } (1..2)]);         
         my $crypted_password = crypt($passwd, $salt);                     
         printf("\nRe-enter password: ");                              
         chomp(my $passwd_re = <STDIN>);                                   
         my $crypted_password_re = crypt($passwd_re, $salt);               
         system "stty echo";                                               
         if ( not ($crypted_password eq $crypted_password_re)) {           
                printf("\nThey don't match; try again.\n");                
                return undef;                                              
         }                                                                 
		 open (PASSFILE, ">>$ARGV[0]") ||
					die "can't open $ARGV[0]: $!";
		 print PASSFILE "$login $crypted_password\n";
		 close PASSFILE;
		 print "\n";
}                                                                         
