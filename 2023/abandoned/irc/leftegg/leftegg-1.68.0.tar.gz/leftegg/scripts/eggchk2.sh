#!/bin/sh

# Enhanced eggchk.sh script. Recommended for using under Solaris.

BOTDIR="/home/ejs/devel/leftegg"
PIDFILEDIR="/home/ejs/devel/leftegg"
CONFIG="/home/ejs/devel/leftegg/egg.cfg"
BOTNICK="leftegg"
BOTSCRIPT="leftegg.pl"

cd $BOTDIR
if test -r $PIDFILEDIR/pid.$BOTNICK; then
     PID=$(cat $PIDFILEDIR/pid.$BOTNICK)
     if $(kill -CHLD $PID >/dev/null 2>&1)
     then
        # everything ok
        echo "everything allright, fellow"
        exit 0
     fi
     echo ""
     echo "stale pid file (erasing it)"
     rm -f $PIDFILEDIR/pid.$BOTNICK
fi
echo ""
echo "LeftEgg is dead, restarting..."
echo ""
if test -x $BOTSCRIPT ;then
   $BOTDIR/$BOTSCRIPT $CONFIG
   exit 0
fi
echo "could not reload, whazzup?"
  
