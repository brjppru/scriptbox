#!/bin/sh

## If you running Solaris - check out eggchk2.sh !!! 

# What this script does:
# check if bot is running
# start it if it's not
# Copyright (c) 1999 Eugen J. Sobchenko

# Warning: this script is not fully checked yet. :(

# Define variables below and add this script to crontab:
# do 'crontab -e' and add string like this:
# 0,10,20,30,40,50 * * * *  /path/to/eggchk.sh 
# or without mail warnings:
# 0,10,20,30,40,50 * * * *  /path/to/eggchk.sh >/dev/null 2>&1

# variables

# where is bot executable located
BOTDIR="/home/ejs/devel/leftegg"  # without '/' at the end

# where is pidfile located
PIDFILEDIR="/home/ejs/devel/leftegg" # without '/' at the end

# where is configuration file
CONFIG="/home/ejs/devel/leftegg/egg.cfg"

# nickname of the bot
BOTNICK="leftegg"

# executable name
BOTSCRIPT="leftegg.pl"



# do not edit below

PIDFILE="$PIDFILEDIR/pid.$BOTNICK"
cd $BOTDIR

if [ -r $PIDFILE ] 
then 
	PID=`cat "$PIDFILE"`
	if [ -r /proc/$PID/cmdline ]
	then
		CHK=`cat "/proc/$PID/cmdline"`
		if [ $CHK=="basename $BOTSCRIPT" ]
		then
			echo "$BOTNICK is running"
		else
			echo "$BOTNICK not running, restarting"
			./$BOTSCRIPT $CONFIGNAME
		fi
	else 
		echo "$BOTNICK not running, restarting"
		./$BOTSCRIPT $CONFIGNAME
	fi
else
	echo "cannot find $PIDFILE. you need to restart bot manually"
fi
 
