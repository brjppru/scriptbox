# Copyright (c) Eugen J. Sobchenko // ejs@paco.net

BEGIN {
    push (@publ_exp, 'do_fortune::^\s*[!]\s*fortune\s*$');
}

sub do_fortune {
    my ($text, $channel, $r_nick, $r_mask) = @_;
    $CFG{'fortune'}="/usr/games/fortune" unless (exists($CFG{'fortune'}));
    my $fortune = `$CFG{'fortune'}`;
    $fortune = join(' ', split("\n", $fortune));
    $fortune = "$r_nick, $fortune";
    irc_msg($channel, $fortune);
}

1;

