# Copyright (c) Eugen J. Sobchenko // ejs@paco.net

BEGIN {
    push (@ctcp_exp, 'ctcp_version::VERSION');
    push (@ctcp_exp, 'ctcp_ping::PING\s+(.*)');
}

sub ctcp_version {
    my ($r_nick, $ctcp_cmd) = @_;
    irc_ctcp($r_nick, "VERSION", "LeftEgg-$VERSION by Eugen J. Sobchenko [ejs\@paco.net], running on $OS.");
}

sub ctcp_ping {
    my ($r_nick, $ctcp_cmd) = @_;
    $ctcp_cmd =~ /PING\s+(.*)/;
    irc_ctcp($r_nick, "PING", "$1");
}

1;
