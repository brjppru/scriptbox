# Copyright (c) Eugen J. Sobchenko // ejs@paco.net

BEGIN {
    push (@publ_exp, 'greet::^(hello|hi|hey|re)\s*$');
}

my @greets = (
"welcome",
"hi",
"hello"
);

sub greet {
    my ($text, $channel, $r_nick, $r_mask) = @_;
    irc_msg($channel, "$r_nick, $greets[int rand scalar @greets]");
    #logit("events.log", "greet to $r_nick", '0600');
}

1;
