# Copyright (c) Eugen J. Sobchenko // ejs@paco.net

BEGIN {
#	$SIG{CHLD}='IGNORE';
    push (@priv_exp, 'get_help::^help\s*(\S*)\s*$');
}

sub get_help {
    my ($text, $r_nick, $r_mask) = @_;
   	$text =~ /\s*help\s*(\S*)\s*$/;
   	my $topic = $1;
    if ($topic =~ /^\s*$/) {
   	    $topic ='help';
   	}
   	$topic =~ tr/A-Z/a-z/;
    if ($help{$topic}) {
   	   foreach my $helpline (@{$help{$topic}{cont}}) {
       	    irc_notice($r_nick,$helpline);
           	sleep(0.5);
       	}
   	} else {
       	unless($topic eq "topics") { irc_notice($r_nick, "no help on $topic"); }
   	}

    if ($topic eq "help" || $topic eq "topics") {
   	    my $helptopics = undef;
		$helptopics= join(", ", (keys %help));
       	irc_notice($r_nick, "help-topics:$helptopics");
   	}
}

1;
