# Copyright (c) Eugen J. Sobchenko // ejs@paco.net

BEGIN {
	$SIG{CHLD}='IGNORE'; # disable zombies
	push (@join_sub, 'join_lim');
	push (@part_sub, 'part_lim');
	push (@quit_sub, 'quit_lim');
	push (@kick_sub, 'kick_lim');
}

# how many time to sleep before change limit
my $sleep=10;
# diff between current nick num and allowed
my $diff=10;

sub join_lim {
	my ($r_nick, $r_host, $channel) = @_;
	if (fork()) {
		#parent 
	} else {
		my $cnt=int scalar @{$names{lc($channel)}};
		$cnt+=$diff;
		sleep($sleep);
		irc_mode($channel, "+l $cnt");
		exit(0);
	}
}

sub part_lim {
    my ($r_nick, $r_host, $channel, $reason) = @_;
    if (fork()) {
        #parent 
    } else {
        my $cnt =int scalar @{$names{lc($channel)}};
        $cnt+=$diff;
        sleep($sleep);
        irc_mode($channel, "+l $cnt");
        exit(0);
    }
}

sub quit_lim {
    my ($r_nick, $r_host, $reason) = @_;
    if (fork()) {
        #parent 
    } else {
		my @where=get_where($r_nick);
		foreach my $channel (@where) {
        	my $cnt =int scalar @{$names{lc($channel)}};
        	$cnt+=$diff;
        	sleep($sleep);
        	irc_mode($channel, "+l $cnt");
		}
        exit(0);
    }
}

sub kick_lim {
	my ($who, $r_nick, $r_host, $channel, $reason) =@_;
    if (fork()) {
        #parent 
    } else {
        my $cnt = scalar @{$names{lc($channel)}};
        $cnt+=$diff;
        sleep($sleep);
        irc_mode($channel, "+l $cnt");
        exit(0);
    }
}


1;

