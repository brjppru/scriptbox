# Copyright (c) Eugen J. Sobchenko // ejs@paco.net

BEGIN {
	push (@priv_exp, 'rehash_userfile::^\s*rehash\s*$');
	push (@priv_exp, 'kill_bot::^\s*die\s*$');
	push (@priv_exp, 'rehash_helpfile::^\s*rehelp\s*$');
    push (@priv_exp, 'save_userfile::^\s*saveusers\s*$');
}

sub save_userfile {
    my ($text, $r_nick, $r_mask) = @_;
    my $res=chkflags($r_nick, $r_mask, "n");
    if ($res eq "true") {
        write_cfg($CFG{userfile});
        irc_notice($r_nick, "userfile rewrited");
    } else {irc_notice($r_nick, "you don't have access, fellow");}
}

sub kill_bot {
    my ($text, $r_nick, $r_mask) = @_;
    my $res=chkflags($r_nick, $r_mask, "n");
    if ($res eq "true") {
        quit_irc("requested by $r_nick");
    } else {
        irc_notice($r_nick, "you don't have access, fellow");
    }
}

sub rehash_userfile {
    my ($text, $r_nick, $r_mask) = @_;
    my $res=chkflags($r_nick, $r_mask, "n");
    if ($res eq "true") {
        parse_userfile($CFG{userfile});
        irc_notice($r_nick, "userfile rehashed");
    } else {
        irc_notice($r_nick, "you don't have access, fellow");
    }
}

sub rehash_helpfile {
	my ($text, $r_nick, $r_mask) = @_;
	my $res=chkflags($r_nick, $r_mask, "n");
	if ($res eq "true") {
		parse_helpfile($CFG{helpfile});
		irc_notice($r_nick, "helpfile rehashed");
	} else {
		irc_notice($r_nick, "you don't have access, fellow");
	}
}

1;
