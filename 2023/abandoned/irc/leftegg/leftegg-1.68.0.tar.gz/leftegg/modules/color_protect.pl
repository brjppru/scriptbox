# Copyright (c) Eugen J. Sobchenko // ejs@paco.net

BEGIN {
    push (@e_publ_exp, 'colorfuck::^.*[\x03].*$');
	push (@e_actn_exp, 'colorfuck::^.*[\x03].*$');
}

my @color_kick_reasons = (
"Colors - suxx",
"Colors are not allowed"
);

sub colorfuck {
    my ($text, $channel, $r_nick, $r_mask) = @_;
	unless (chkflags($r_nick, $r_mask, "n|o|O") eq 'true') {
		irc_kick($channel, $r_nick, $color_kick_reasons[int rand scalar @color_kick_reasons]);
	} else {
		logit('events.log', "Colors from operator. $r_nick [$r_mask} at $channel", '0600');
	}
}

1;
