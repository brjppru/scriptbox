# Copyright (c) Eugen J. Sobchenko // ejs@paco.net

BEGIN {
    push (@publ_exp, 'get_seen::^\s*\!?seen\s+(\S+)\s*$');
    push (@priv_exp, 'get_seen::^\s*\!?seen\s+(\S+)\s*$');
	push (@publ_exp, 'add_seen::.*');
	push (@actn_exp, 'add_seen::.*');

$CFG{'seendb'}="seen.db";
	use strict;
}


my @notseen = (
"I have never seen this fellow alive, sorry",
"I've never seen this dude alive",
"sorry, I've never seen this man alive"
);


sub get_seen {
    my ($text, $to, $r_nick, $r_host);
    if ((scalar @_) == 4) {
        ($text, $to, $r_nick, $r_host) = @_;
    } else {
        ($text, $r_nick, $r_host) = @_;
        $to = $r_nick;
    }
    my %seen_db;
    my %tmp_hash;
    unless ($CFG{noloadseen}==1) {
	unless (-e "$CFG{datadir}/$CFG{seendb}") {
			irc_msg($to, "$r_nick, $notseen[int rand scalar @notseen]");
			return;
	}
        my $db=tie %seen_db, "DB_File", "$CFG{datadir}/$CFG{seendb}", O_RDWR, 0444;
	    my $fd = $db->fd();
    	open DATA, "+<&=$fd";
    	flock(DATA, LOCK_SH);
        $text=~/seen\s+(\S+)\s*$/;
        my $nick=$1;
        my $anick=lc($nick);
        if (exists($seen_db{"$anick"}) && $anick ne lc $CFG{nick} && $anick ne lc $r_nick) {
            my ($istime,$ischannel)=split ('::', $seen_db{$anick});
            my $diff=time_diff($istime);
            irc_msg($to, "$r_nick, I last saw $anick alive $diff ago at $ischannel");
        } elsif ($anick eq lc $r_nick) {
            irc_msg($to, "$r_nick, yes, I see you");
        } elsif ($anick eq lc $CFG{nick}) {
            irc_msg($to, "$r_nick, I'm here and alive :-)");
        } else {
			my @maybe;
			foreach my $fellow (keys %seen_db) {
				my $exp1=quotemeta($anick);
				my $exp2=quotemeta($fellow);
				if ($exp1 =~ /$exp2/) {
                    my ($t,$c)=split ('::', $seen_db{$fellow});
                    $tmp_hash{$t}=$fellow;
				} elsif ($exp2 =~ /$exp1/) {
                    my ($t,$c)=split ('::', $seen_db{$fellow});
                    $tmp_hash{$t}=$fellow;
				}
			}
			if (scalar(keys %tmp_hash) > 0) {
                foreach (sort {$b <=> $a} keys %tmp_hash) {
                    push @maybe, $tmp_hash{$_};
                }
				splice(@maybe, 3) if (scalar(@maybe) > 3);
				my $m = join(' or ', @maybe);
				irc_msg($to, "$r_nick, $notseen[int rand scalar @notseen]. Maybe you mean $m?");
			} else {			
            	irc_msg($to, "$r_nick, $notseen[int rand scalar @notseen]");
			}			
        }
       undef $db;
       undef %tmp_hash;
       untie %seen_db;
       close DATA;
    }
}

sub add_seen {
	my ($text, $channel, $nick, $r_mask) = @_;
	return if $nick eq '';
    my $istime = time;
#	my $isdate = now_date();
    my %seen_db;
    my $db=tie %seen_db, "DB_File", "$CFG{datadir}/$CFG{seendb}", O_RDWR|O_CREAT, 0666;
    my $fd=$db->fd();
    open DATA, "+<&=$fd";
    flock(DATA, LOCK_EX);
    $nick=lc($nick);
	$seen_db{"$nick"}="$istime"."::"."$channel";
        $db->sync;
        undef $db;
        untie %seen_db;
        close DATA;
}

1;
