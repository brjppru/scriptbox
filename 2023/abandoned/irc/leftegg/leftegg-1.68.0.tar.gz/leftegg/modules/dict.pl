# Copyright (c) Eugen J. Sobchenko // ejs@paco.net

BEGIN {
    push (@publ_exp, 'learn_new_word::^\s*.?\s*dictadd\s+(.+?)\s+=\s+(.+)\s*$');
    push (@priv_exp, 'learn_new_word::^\s*.?\s*dictadd\s+(.+?)\s+=\s+(.+)\s*$');
    push (@publ_exp, 'forget_word::^\s*.?\s*dictdel\s+(.+\S)\s*$');
    push (@priv_exp, 'forget_word::^\s*.?\s*dictdel\s+(.+\S)\s*$');
    push (@publ_exp, 'get_word::^\s*.?\s*translate\s*(.+)\s*');
    push (@priv_exp, 'get_word::^\s*.?\s*translate\s*(.+)\s*');
    push (@priv_exp, 'word_cnt::^\s*.?\s*wordcount\s*');
    push (@publ_exp, 'word_cnt::^\s*.?\s*wordcount\s*');

$CFG{'dictfile'}="dict.db";
}

sub learn_new_word {
    my ($text, $to, $r_nick, $r_host);
    if ((scalar @_) == 4) {
        ($text, $to, $r_nick, $r_host) = @_;
    } else {
        ($text, $r_nick, $r_host) = @_;
        $to = $r_nick;
    }
    if ($CFG{dictprotect} eq '1') {
    irc_notice($r_nick, "you don't have access, fellow") && return 
        unless (chkflags($r_nick, $r_host, "n") eq 'true'); 
    }
    my %dict_db;
    my $db=tie %dict_db, "DB_File", "$CFG{datadir}/$CFG{dictfile}", O_RDWR|O_CREAT, 0666; 
	my $fd=$db->fd();
	open DATA, "+<&=$fd";
	flock(DATA, LOCK_EX);
    $text =~ /dictadd\s+(.+?)\s+=\s+(.+)\s*$/i;
    my $key = lc($1);
    unless (exists($dict_db{"$key"})) {
        $dict_db{"$key"} = $2;
        $db->sync;
		undef $db;
        untie %dict_db;
		close DATA;
        irc_msg($to, "$r_nick, done");
    } else {
		undef $db;
        untie %dict_db;
		close DATA;
        irc_msg($to, "$r_nick, already exists, sorry...");
    }
}

sub word_cnt {
    my ($text, $to, $r_nick, $r_host);
    if ((scalar @_) == 4) {
        ($text, $to, $r_nick, $r_host) = @_;
    } else {
        ($text, $r_nick, $r_host) = @_;
        $to = $r_nick;
    }
	if (-e "$CFG{datadir}/$CFG{dictfile}") {
    	my %dict_db;
    	my $db=tie %dict_db, "DB_File", "$CFG{datadir}/$CFG{dictfile}", O_RDWR, 0444;
    	my $fd = $db->fd();
    	open DATA, "+<&=$fd";
    	flock(DATA, LOCK_SH);
    	my $count=0;
    	foreach (keys %dict_db) {
        	$count++;
    	}
    	undef $db;
	    untie %dict_db;
    	close DATA;
    	irc_msg($to, "$r_nick, I have $count words in my dictionary");
	} else {irc_msg($to, "$r_nick, I have 0 words in my dictionary"); }
}

sub forget_word {
    my ($text, $to, $r_nick, $r_host);
    if ((scalar @_) == 4) {
        ($text, $to, $r_nick, $r_host) = @_;
    } else {
        ($text, $r_nick, $r_host) = @_;
        $to = $r_nick;
    }
    if ($CFG{dictprotect} eq '1') { 
    irc_notice($r_nick, "you don't have access, fellow") && return  
            unless (chkflags($r_nick, $r_host, "n") eq 'true');
    }
	if (-e "$CFG{datadir}/$CFG{dictfile}") {
    	my %dict_db;
    	my $db=tie %dict_db, "DB_File", "$CFG{datadir}/$CFG{dictfile}", O_RDWR|O_CREAT, 0666;
    	my $fd=$db->fd();
    	open DATA, "+<&=$fd";
    	flock(DATA, LOCK_EX);
    	$text =~ /dictdel\s+(.+\S)\s*$/i;
    	my $key = lc($1);
    	if (exists($dict_db{"$key"})) {
        	delete $dict_db{"$key"};
        	$db->sync;
        	undef $db;
        	untie %dict_db;
        	close DATA;
        	irc_msg($to, "$r_nick, done");
    	} else {
        	undef $db;
        	untie %dict_db;
        	close DATA;
        	irc_msg($to, "$r_nick, not exists");
    	}
	} else { irc_msg($to, "$r_nick, not exists"); }
}

sub get_word {
    my ($text, $to, $r_nick, $r_host);
    if ((scalar @_) == 4) {
        ($text, $to, $r_nick, $r_host) = @_;
    } else {
        ($text, $r_nick, $r_host) = @_;
        $to = $r_nick;
    }
	if (-e "$CFG{datadir}/$CFG{dictfile}") {
    	my %dict_db;
    	my $db=tie %dict_db, "DB_File", "$CFG{datadir}/$CFG{dictfile}", O_RDWR, 0444;
		my $fd = $db->fd();
		open DATA, "+<&=$fd";
		flock(DATA, LOCK_SH);
    	$text =~ /translate\s*(.+)\s*/;
    	my $key = lc($1);
    	if (exists($dict_db{"$key"})) {
        	irc_msg($to, "$r_nick, $1 = $dict_db{$key}");
    	} else {
        	irc_msg($to, "$r_nick, no such word in my dictionary");
    	}
		undef $db;
		untie %dict_db;
		close DATA;
	} else { irc_msg($to, "$r_nick, no such word in my dictionary"); }
}

1;
