# Copyright (c) Eugen J. Sobchenko // ejs@paco.net

use strict;

BEGIN {
    push (@priv_exp, 'add_forward::^\s*addfwd\s+([\#\&]\S+)\s+(\S+)\s*$');
    push (@priv_exp, 'del_forward::^\s*delfwd\s+([\#\&]\S+)\s+(\S+)\s*$');
    push (@priv_exp, 'list_forward::^\s*fwdlist\s*$');
	push (@actn_exp, 'actionfwd::.*');
	push (@publ_exp, 'publfwd::.*');
	push (@join_sub, 'joinfwd');
	push (@part_sub, 'partfwd');
	push (@quit_sub, 'quitfwd');
	push (@kick_sub, 'kickfwd');
	push (@mode_sub, 'modefwd');
	push (@topic_sub, 'topicfwd');
	push (@nick_sub, 'nickfwd');
}

sub actionfwd {
	my ($text, $channel, $r_nick, $r_host) =@_;
	if (exists($fwd{$channel})) {
		foreach (@{$fwd{$channel}}) {
			irc_msg($_, "* $r_nick/$channel $text");
		}
	}
}

sub publfwd {
	my ($text, $channel, $r_nick, $r_host) =@_;
	if (exists($fwd{$channel})) {
		foreach (@{$fwd{$channel}}) {
			irc_msg($_, "<$r_nick/$channel> $text");
		}
	}
}

sub joinfwd {
	my ($r_nick, $r_host, $channel)=@_;
	if (exists($fwd{lc($channel)})) {
		foreach (@{$fwd{lc($channel)}}) {
			irc_msg($_, "*** $r_nick has joined $channel");
		}
	}
}

sub partfwd {
	my ($r_nick, $r_host, $channel, $reason) =@_;
	if (exists($fwd{lc($channel)})) {
		foreach (@{$fwd{lc($channel)}}) {
			irc_msg($_, "*** $r_nick has left channel $channel ($reason)");
		}
	}
}

sub quitfwd {
	my ($r_nick, $r_host, $reason)=@_;
	my @where = get_where($r_nick);
	foreach my $wn (@where) {
		if (exists($fwd{$wn})) {
			foreach (@{$fwd{$wn}}) {
				irc_msg($_, "*** $r_nick has quit irc ($reason)");
			}
		}
	}
}

sub modefwd {
	my ($r_nick, $r_host, $channel, $mode, @qax)=@_;
	if (exists($fwd{lc($channel)})) {
		foreach (@{$fwd{lc($channel)}}) {
			if (@qax) {
				irc_msg($_, "*** mode $mode ".join(' ', @qax)." on $channel by $r_nick");
			} else {
				irc_msg($_, "*** mode $mode on $channel by $r_nick");
			}
		}
	}
}

sub topicfwd {
	my ($channel, $topic, $r_nick, $r_host)=@_;
	if (exists($fwd{lc($channel)})) {
		foreach (@{$fwd{lc($channel)}}) {
			irc_msg($_, "*** $r_nick has changed topic on $channel to: $topic");
		}
	}
}

sub nickfwd {
	my ($r_nick, $r_host, $newnick) =@_;
	my @where = get_where($newnick);
	foreach my $cn (@where) {
		if (exists($fwd{lc($cn)})) {
			foreach (@{$fwd{lc($cn)}}) {
				irc_msg($_, "*** $r_nick has changed nick to $newnick");
			}
		}
	}
}

sub kickfwd {
	my ($who, $r_nick, $r_host, $channel, $reason) =@_;
	if (exists($fwd{lc($channel)})) {
		foreach (@{$fwd{lc($channel)}}) {
			irc_msg($_, "*** $who was kicked from $channel by $r_nick ($reason)");
		}
	}
}

sub add_forward {
    my ($text, $r_nick, $r_mask) = @_;
    my $res=chkflags($r_nick, $r_mask, "n");
    if ($res eq "true") {
        $text=~/addfwd\s+([\#\&]\S+)\s+(\S+)\s*$/;
        my $channel=$1;
        my $to=$2;
        $channel=lc($channel);
        $to=lc($to);
        $res=is_exists($channel, $to);
        if ($res ne"true") {
            push @{$fwd{$channel}}, $to;
            irc_notice($r_nick, "now forwarding from $channel to $to");
        } else { irc_notice($r_nick, "this forward already exists"); }
    } else {
        irc_notice($r_nick, "you don't have access, fellow");
	}
}

sub del_forward {
    my ($text, $r_nick, $r_mask) = @_;
    my $res=chkflags($r_nick, $r_mask, "n");
    if ($res eq"true") {
        $text=~/delfwd\s+([\#\&]\S+)\s+(\S+)\s*$/;
        my $channel=$1;
        my $to=$2;
        $channel=lc($channel);
        $to=lc($to);
        my $success=0;
        if (scalar(@{$fwd{$channel}}) == 1) {
            delete $fwd{"$channel"};
            irc_notice($r_nick, "forwarding from $channel to $to now removed");
        } else {
            for (my $i=0; $i<=(scalar(@{$fwd{$channel}})); $i++) {
                if (lc ${$fwd{$channel}}[$i] eq lc $to) {
                    splice(@{$fwd{$channel}}, $i, 1);
                    $success=1;
                }
            }
            if ($success==1) {
                irc_notice($r_nick, "forwarding from $channel to $to now removed");
            } else {
                irc_notice($r_nick, "no such forward exists");
            }
        }
    } else {
        irc_notice($r_nick, "you don't have access, fellow");
    }
}

sub list_forward {
    my ($text, $r_nick, $r_mask) = @_;
    my $res=chkflags($r_nick, $r_mask, "n");
    if ($res eq"true") {
        if (scalar(keys %fwd) != 0) {
            irc_notice($r_nick, "Current forwards:");
            foreach my $channel (keys %fwd) {
                my $tos = join (", ", @{$fwd{$channel}});
                irc_notice($r_nick, "from $channel to: $tos");
            }
		} else { irc_notice($r_nick, "no forwards exists"); }
    } else {
        irc_notice($r_nick, "you don't have access, fellow");
    }
}

sub is_exists {
    my ($from, $to) = @_;
    if (exists($fwd{$from})) {
        foreach my $nick (@{$fwd{$from}}) {
            if ($nick eq $to) {
                return "true";
            }
        }
    } else {
        return "suxx";
    }
    return "suxx";
}

1;
