# Copyright (c) Eugen J. Sobchenko // ejs@paco.net

use strict;

BEGIN {
    push (@priv_exp, 'op_user::^\s*op\s+(\S+)\s*(\S*)\s*$');
    push (@priv_exp, 'get_whois::^\s*whois\s+(\S+)\s*$');
    push (@priv_exp, 'list_reg::^\s*listreg\s*$');
    push (@priv_exp, 'join_chan::^\s*join\s+(\S+)\s*(\S*)\s*$');
    push (@priv_exp, 'part_chan::^\s*leave\s+(\S+)\s*(.*)\s*$');
    push (@priv_exp, 'mode_chan::^\s*mode\s+(\S+)\s+(.+\S)\s*$');
    push (@priv_exp, 'get_uptime::^\s*uptime\s*$');
    push (@priv_exp, 'voice_user::^\s*voice\s+(\S+)\s*(\S*)\s*$');
    push (@priv_exp, 'say_it::^\s*say\s+(\S+)\s+(.+)\s*$');
	push (@priv_exp, 'topic_ch::^\s*topic\s+(\S+)\s+(.+)\s*$');
	push (@priv_exp, 'show_owner::^\s*owner');
	push (@priv_exp, 'kick_user::^\s*kick\s+(\S+)\s+(\S+)\s*(.*?)\s*$');
    push (@priv_exp, 'chparam::^\s*chparam\s+(\S+)\s+(\S+)\s+(.+?)\s*$');
    push (@priv_exp, 'delparam::^\s*delparam\s+(\S+)\s+(\S+)\s*$');
    push (@priv_exp, 'del_userf::^\s*deluser\s+(\S+)\s*$');
    push (@priv_exp, 'change_nickname::^\s*chnick\s+(\S+)\s*$');
}

sub change_nickname {
    my ($text, $r_nick, $r_mask) = @_;
    my $res=chkflags($r_nick, $r_mask, "n");
    if ($res eq "true") {
        $text=~/^\s*chnick\s+(\S+)\s*$/;
        ch_nick($1);
        $nickorig = $1;
    } else {irc_notice($r_nick, "you don't have access, fellow");}
}

sub chparam {
    my ($text, $r_nick, $r_mask) = @_;
    my $res=chkflags($r_nick, $r_mask, "n");
    if ($res eq "true") {
        $text =~ /^\s*chparam\s+(\S+)\s+(\S+)\s+(.+?)\s*$/;
        my $arg = $3;
        push @users, $1 unless (exists($reg_users{$1}));
        if (lc $2 eq 'masks') {
            undef @{$reg_users{$1}{lc($2)}};
            push @{$reg_users{$1}{lc($2)}}, split(/\s+/, $arg);
        } else {
            $reg_users{$1}{lc($2)}=$arg;
        }
        irc_notice($r_nick, "done");
    } else {irc_notice($r_nick, "you don't have access, fellow");}
}

sub delparam {
    my ($text, $r_nick, $r_mask) = @_;
    my $res=chkflags($r_nick, $r_mask, "n");
    if ($res eq "true") {
        $text =~ /^\s*delparam\s+(\S+)\s+(\S+)\s*$/;
        delete($reg_users{$1}->{$2});
        irc_notice($r_nick, "done");
    } else {irc_notice($r_nick, "you don't have access, fellow");}
}

sub del_userf {
    my ($text, $r_nick, $r_mask) = @_;
    my $res=chkflags($r_nick, $r_mask, "n");
    if ($res eq "true") {
        $text =~ /^\s*deluser\s+(\S+).*$/;
        if (exists($reg_users{$1})) {
        delete($reg_users{$1});
        for (my $i=0; $i<(scalar(@users)); $i++) {
            if (lc $users[$i] eq lc $1) {
                splice(@users, $i, 1);
            }
        }
        irc_notice($r_nick, "user $1 deleted");
        } else { irc_notice($r_nick, "no such user");}
    } else {
        irc_notice($r_nick, "you don't have access, fellow");
    }
}

sub join_chan {
    my ($text, $r_nick, $r_mask) = @_;
    my $res=chkflags($r_nick, $r_mask, "n");
    if ($res eq "true") {
        $text =~ /join\s+(\S+)\s*(\S*)\s*$/;
        my $channel = $1;
		foreach (@channels) {
			if (lc $channel eq $_) {
				irc_notice($r_nick, "already on $channel");
				return 1;
			}
		}
        if ($2) {
            my $key = $2;
            irc_join_chan($channel, $key);
        } else {
            irc_join_chan($channel);
		}
    } else {irc_notice($r_nick, "you don't have access, fellow");}
}

sub mode_chan {
    my ($text, $r_nick, $r_mask) = @_;
    my $res=chkflags($r_nick, $r_mask, "n|o|O");
    if ($res eq"true") {
        $text=~/mode\s+(\S+)\s+(.+\S)\s*$/;
		irc_notice($r_nick, "I'm not opped on $1") && return if 
			(is_opped($CFG{'nick'}, $1) ne "true");
        irc_mode($1,$2);
    } else {
        irc_notice($r_nick, "you don't have access, fellow");
    }
}

sub part_chan {
    my ($text, $r_nick, $r_mask) = @_;
    my $res=chkflags($r_nick, $r_mask, "n");
    if ($res eq "true") {
        $text =~ /leave\s+(\S+)\s*(.*)\s*$/;
        my $channel = $1;
        if ($2) {
            my $reason = $2;
            irc_leave_chan($channel, $reason);
        } else {
            irc_leave_chan($channel);
        }
    } else {irc_notice($r_nick, "you don't have access, fellow");}
}

sub op_user {
    my ($text, $r_nick, $r_mask) = @_;
    $text =~ /op\s+(\S+)\s*(\S*)\s*$/;
    unless($2) {
        my $res=chkflags($r_nick, $r_mask, "n|o|O");
        if ($res eq "true") {
	        irc_notice($r_nick, "I'm not opped on $1") && return if
    	        (is_opped($CFG{'nick'}, $1) ne "true");

            irc_mode($1, "+o $r_nick");
        } else {
            irc_notice($r_nick, "you don't have access, fellow");
        }
    } else {
        my $nick = $1;
        my $channel = $2;
        my $res=chkflags($r_nick, $r_mask, "n|o|O");
        if ($res eq"true") {
	        irc_notice($r_nick, "I'm not opped on $channel") && return if
    	        (is_opped($CFG{'nick'}, $channel) ne "true");

            irc_mode($channel, "+o $nick");
        } else {
            irc_notice($r_nick, "you don't have access, fellow");
        }
    }
}

sub voice_user {
    my ($text, $r_nick, $r_mask) = @_;
    $text =~ /voice\s+(\S+)\s*(\S*)\s*$/;
    unless($2) {
        my $res=chkflags($r_nick, $r_mask, "n|o|v|O|V");
        if ($res eq "true") {
	        irc_notice($r_nick, "I'm not opped on $1") && return if
    	        (is_opped($CFG{'nick'}, $1) ne "true");

            irc_mode($1, "+v $r_nick");
        } else {
            irc_notice($r_nick, "you don't have access, fellow");
        }
    } else {
        my $nick = $1;
        my $channel = $2;
        my $res=chkflags($r_nick, $r_mask, "n|o|O");
        if ($res eq"true") {
    	    irc_notice($r_nick, "I'm not opped on $channel") && return if
	            (is_opped($CFG{'nick'}, $channel) ne "true");

            irc_mode($channel, "+v $nick");
        } else {
            irc_notice($r_nick, "you don't have access, fellow");
        }
    }
}


sub topic_ch {
	my ($text, $r_nick, $r_mask) = @_;
	my $res=chkflags($r_nick, $r_mask, "n|o|O");
	if ($res eq"true") {
		$text =~ /^\s*topic\s+(\S+)\s+(.+)\s*$/;
        irc_notice($r_nick, "I'm not opped on $1") && return if
            (is_opped($CFG{'nick'}, $1) ne "true");

		ch_topic($1, $2);
	} else {irc_notice($r_nick, "you don't have access, fellow");}
}

sub show_owner {
	my ($text, $r_nick, $r_mask) = @_;
	irc_notice($r_nick, "my owner is $CFG{owner}");
}

sub say_it {
    my ($text, $r_nick, $r_mask) = @_;
    my $res=chkflags($r_nick, $r_mask, "n|o|O");
    if ($res eq "true") {
        $text=~/say\s+(\S+)\s+(.+)\s*$/;
        my $to=$1;
        my $msg=$2;
		irc_msg($to, $msg);
    } else {irc_notice($r_nick, "you don't have access, fellow");}
}

sub get_whois {
    my ($text, $r_nick, $r_mask) = @_;
    undef my @masks;
    $text =~ /whois\s+(\S+)\s*$/;
    my $handle = $1;
    foreach my $user (@users) {
        if ($handle =~ /$user/i) {
            if ($reg_users{$user}->{flags}) {
            irc_notice($r_nick, "Found $handle with flags: ".$reg_users{$user}->{flags});
            }else {irc_notice($r_nick, "Found $handle with no flags.");}
            my @masks=@{$reg_users{$user}{masks}} if ($reg_users{$user}{masks});
            if (defined($masks[0])) {
                irc_notice($r_nick, "masks:");
                foreach my $mask (@masks) {
                    #$mask =~ s/\.\*\?/\*/g;
                    #$mask =~ s/\\//g;
                    irc_notice($r_nick, "  -> $mask");
                }
            }
            #if (defined($reg_users{$user}{greet})) {
            #    irc_notice($r_nick, "Greet: ".$reg_users{$user}->{greet});
            #}
            foreach (sort keys %{$reg_users{$user}}) {
                unless (lc $_ eq 'flags' || lc $_ eq 'masks') { 
                    irc_notice($r_nick, "$_: ".$reg_users{$user}->{$_});
                }
            }
            return 1;
        }
    }
    irc_notice($r_nick, "cannot find $handle in my userfile");
}

sub get_uptime {
    my ($text, $r_nick, $r_mask) = @_;
    my $diff=time_diff($START_TIME);
    irc_notice($r_nick, "my uptime is $diff");
}

sub list_reg {
    my ($text, $r_nick, $r_mask) = @_;
    my $users = join(', ', @users);
    irc_notice($r_nick, "registered users:$users");
}

sub kick_user {
	my ($text, $r_nick, $r_mask) = @_;
	my $res=chkflags($r_nick, $r_mask, "n|o|O");
	if ($res eq "true") {
		if ($text =~ /^\s*kick\s+(\S+)\s+(\S+)\s+(.+)\s*$/) {	
	        irc_notice($r_nick, "I'm not opped on $2") && return if
    	        (is_opped($CFG{'nick'}, $2) ne "true");

			irc_kick($2, $1, $3);
		} elsif ($text =~ /^\s*kick\s+(\S+)\s+(\S+)\s*$/) {
   		     irc_notice($r_nick, "I'm not opped on $2") && return if
        	    (is_opped($CFG{'nick'}, $2) ne "true");
			my $reason="requested by $r_nick";
            irc_kick($2, $1, $reason);
		}
	} else {irc_notice($r_nick, "you don't have access, fellow");}
}

1;
