# Copyright (c) Eugen J. Sobchenko // ejs@paco.net

BEGIN {
    push (@publ_exp, 'learn_new_fact::^\s*[!]\s*(.+)\s+(is|are|was|were|been|at|on|in)\s+(.+)\s*');
    push (@priv_exp, 'learn_new_fact::^\s*[!]\s*(.+)\s+(is|are|was|were|been|at|on|in)\s+(.+)\s*');
    push (@publ_exp, 'forget_fact::^\s*[!]\s*forget\s+(.+\S)\s*');
    push (@priv_exp, 'forget_fact::^\s*[!]\s*forget\s+(.+\S)\s*');
    push (@publ_exp, 'get_fact::^\s*[?]\s*(.+)\s*');
    push (@priv_exp, 'get_fact::^\s*[?]\s*(.+)\s*');
    push (@priv_exp, 'fact_cnt::^\s*[!]\s*factcount\s*');
    push (@publ_exp, 'fact_cnt::^\s*[!]\s*factcount\s*');

$CFG{'datafile'}="facts.db";
}

my @reply_fact_quote = (
"I heard",
"I know",
"I think"
);

my @dont_know_quote = (
"sorry, I don't know",
"I don't know, sorry",
"hmm... I don't know"
);

my @accept_quote = (
"accepted",
"okay",
"gotcha"
);

my @exist_quote = (
"this element already exist",
"sorry, but this element already in my database",
"I already have this element in my database"
);

my @notexist_quote = (
"this elemen't does not exist",
"this elemen't not exist, sorry",
"this element not exist yet"
);

sub learn_new_fact {
    my ($text, $to, $r_nick, $r_host);
    if ((scalar @_) == 4) {
        ($text, $to, $r_nick, $r_host) = @_;
    } else {
        ($text, $r_nick, $r_host) = @_;
        $to = $r_nick;
    }
    my %facts_db;
    my $db=tie %facts_db, "DB_File", "$CFG{datadir}/$CFG{datafile}", O_RDWR|O_CREAT, 0666; 
	my $fd=$db->fd();
	open DATA, "+<&=$fd";
	flock(DATA, LOCK_EX);
    $text =~ /\s*[!]\s*(.+?)\s+(is|are|was|were|been|at|on|in)\s+(.+)\s*/i;
    my $key = lc($1);
    unless (exists($facts_db{"$key"})) {
        $facts_db{"$key"} = "$2 $3";
        $db->sync;
		undef $db;
        untie %facts_db;
		close DATA;
        irc_msg($to, "$r_nick, $accept_quote[int rand scalar @accept_quote]");
    } else {
		undef $db;
        untie %facts_db;
		close DATA;
        irc_msg($to, "$r_nick, $exist_quote[int rand scalar @exist_quote]");
    }
}

sub fact_cnt {
    my ($text, $to, $r_nick, $r_host);
    if ((scalar @_) == 4) {
        ($text, $to, $r_nick, $r_host) = @_;
    } else {
        ($text, $r_nick, $r_host) = @_;
        $to = $r_nick;
    }
	if (-e "$CFG{datadir}/$CFG{datafile}") {
    	my %facts_db;
    	my $db=tie %facts_db, "DB_File", "$CFG{datadir}/$CFG{datafile}", O_RDWR, 0444;
    	my $fd = $db->fd();
    	open DATA, "+<&=$fd";
    	flock(DATA, LOCK_SH);
    	my $count=0;
    	foreach (keys %facts_db) {
        	$count++;
    	}
    	undef $db;
	    untie %facts_db;
    	close DATA;
    	irc_msg($to, "$r_nick, I have $count facts in my database");
	} else {irc_msg($to, "$r_nick, I have 0 facts in my database"); }
}

sub forget_fact {
    my ($text, $to, $r_nick, $r_host);
    if ((scalar @_) == 4) {
        ($text, $to, $r_nick, $r_host) = @_;
    } else {
        ($text, $r_nick, $r_host) = @_;
        $to = $r_nick;
    }
	if (-e "$CFG{datadir}/$CFG{datafile}") {
    	my %facts_db;
    	my $db=tie %facts_db, "DB_File", "$CFG{datadir}/$CFG{datafile}", O_RDWR|O_CREAT, 0666;
    	my $fd=$db->fd();
    	open DATA, "+<&=$fd";
    	flock(DATA, LOCK_EX);
    	$text =~ /\s*[!]\s*forget\s+(.+\S)\s*/i;
    	my $key = lc($1);
    	if (exists($facts_db{"$key"})) {
        	delete $facts_db{"$key"};
        	$db->sync;
        	undef $db;
        	untie %facts_db;
        	close DATA;
        	irc_msg($to, "$r_nick, $accept_quote[int rand scalar @accept_quote]");
    	} else {
        	undef $db;
        	untie %facts_db;
        	close DATA;
        	irc_msg($to, "$r_nick, $notexist_quote[int rand scalar @notexist_quote]");
    	}
	} else { irc_msg($to, "$r_nick, $notexist_quote[int rand scalar @notexist_quote]"); }
}

sub get_fact {
    my ($text, $to, $r_nick, $r_host);
    if ((scalar @_) == 4) {
        ($text, $to, $r_nick, $r_host) = @_;
    } else {
        ($text, $r_nick, $r_host) = @_;
        $to = $r_nick;
    }
	if (-e "$CFG{datadir}/$CFG{datafile}") {
    	my %facts_db;
    	my $db=tie %facts_db, "DB_File", "$CFG{datadir}/$CFG{datafile}", O_RDWR, 0444;
		my $fd = $db->fd();
		open DATA, "+<&=$fd";
		flock(DATA, LOCK_SH);
    	$text =~ /\s*[?]\s*(.+)\s*/;
    	my $key = lc($1);
    	if (exists($facts_db{"$key"})) {
        	irc_msg($to, "$r_nick, $reply_fact_quote[int rand scalar @reply_fact_quote] $1 $facts_db{$key}");
    	} else {
        	irc_msg($to, "$r_nick, $dont_know_quote[int rand scalar @dont_know_quote]");
    	}
		undef $db;
		untie %facts_db;
		close DATA;
	} else { irc_msg($to, "$r_nick, $dont_know_quote[int rand scalar @dont_know_quote]"); }
}

1;
